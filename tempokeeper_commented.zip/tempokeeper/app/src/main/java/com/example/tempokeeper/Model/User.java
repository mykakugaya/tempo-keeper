package com.example.tempokeeper.Model;

public class User {
    public String country;
    public String display_name;
    public String email;
    public String id;
}
