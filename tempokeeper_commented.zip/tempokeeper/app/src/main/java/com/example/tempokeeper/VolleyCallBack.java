package com.example.tempokeeper;

public interface VolleyCallBack {
    void onSuccess();
}
